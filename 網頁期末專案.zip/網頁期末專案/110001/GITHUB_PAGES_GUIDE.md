# GitHub Pages 部署指南

## 概述

本指南將幫助你將個人網站部署到 GitHub Pages，使其可以通過網址訪問。

## 前提條件

1. ✅ 已安裝 Git
2. ✅ 已建立 GitHub 帳號
3. ✅ 所有網站文件已準備好（HTML、CSS、JS、Images）

## 部署步驟

### 步驟 1: 建立 GitHub 倉庫

#### 方式 1: 建立個人網站倉庫（推薦）

1. 登入 GitHub: https://github.com
2. 點擊右上角 "+" → "New repository"
3. 填寫倉庫信息：
   - **Repository name**: `username.github.io`
     （將 `username` 替換為你的 GitHub 用戶名）
   - **Description**: 個人網站
   - **Visibility**: Public（公開）
   - **Initialize this repository**: 不勾選
4. 點擊 "Create repository"

#### 方式 2: 建立一般倉庫

1. 建立新倉庫，名稱為 `portfolio` 或 `personal-website`
2. 後續在 Settings 中啟用 GitHub Pages

### 步驟 2: 準備本地文件

1. 在本地創建項目文件夾（或使用現有的 `110001` 文件夾）
2. 確保文件結構如下：

```
110001/
├── index.html
├── style.css
├── script.js
├── README.md
└── images/
    ├── profile.jpg
    ├── about.jpg
    ├── project1.jpg
    ├── project2.jpg
    ├── project3.jpg
    ├── activity1.jpg
    ├── activity2.jpg
    ├── activity3.jpg
    └── activity4.jpg
```

### 步驟 3: 初始化 Git 倉庫

1. **打開命令行/PowerShell**
   - Windows: 在文件夾中右鍵 → "在此處打開 PowerShell" 或 "Git Bash"
   - Mac/Linux: 打開終端機

2. **進入項目目錄**
   ```bash
   cd c:\Users\USER\Desktop\網頁期末專案\110001
   ```
   或
   ```bash
   cd C:\Users\USER\Desktop\網頁期末專案\110001
   ```

3. **初始化 Git**
   ```bash
   git init
   ```

4. **配置 Git（首次）**
   ```bash
   git config user.name "Your Name"
   git config user.email "your.email@example.com"
   ```

### 步驟 4: 提交文件到本地倉庫

1. **添加所有文件**
   ```bash
   git add .
   ```

2. **提交文件**
   ```bash
   git commit -m "Initial commit: Personal website"
   ```

   提交信息範例：
   - "Add personal website project"
   - "Initial version with all sections"
   - "Add responsive design and interactive features"

### 步驟 5: 連接到 GitHub 倉庫

1. **添加遠端倉庫**
   ```bash
   git remote add origin https://github.com/username/username.github.io.git
   ```
   
   或（使用 SSH）：
   ```bash
   git remote add origin git@github.com:username/username.github.io.git
   ```
   
   將 `username` 替換為你的 GitHub 用戶名

2. **驗證連接**
   ```bash
   git remote -v
   ```

### 步驟 6: 推送到 GitHub

1. **推送主分支**
   ```bash
   git branch -M main
   git push -u origin main
   ```

   首次推送時可能需要輸入 GitHub 帳號和密碼（或 token）

2. **驗證上傳**
   - 訪問 GitHub 倉庫頁面檢查文件是否已上傳

### 步驟 7: 啟用 GitHub Pages

#### 對於個人網站倉庫 (username.github.io)

1. GitHub Pages 會自動啟用
2. 訪問 `https://username.github.io` 查看網站
3. 通常需要等待 5-10 分鐘才能生效

#### 對於一般倉庫

1. 進入倉庫 Settings（設定）
2. 左側菜單找到 "Pages"
3. 在 "Source" 下拉菜單選擇 "main" 分支
4. 點擊 "Save"
5. 網站將在 `https://username.github.io/repository-name` 上線

### 步驟 8: 驗證網站

1. 訪問你的網站 URL：
   - 個人網站: `https://username.github.io`
   - 一般倉庫: `https://username.github.io/110001`

2. 檢查：
   - ✅ 頁面是否正確載入
   - ✅ 圖片是否顯示
   - ✅ CSS 樣式是否生效
   - ✅ JavaScript 功能是否正常
   - ✅ 導航連結是否工作

## 常見問題

### 問題 1: 頁面未出現或顯示 404

**可能原因**:
- GitHub Pages 還在部署中（需要等待 5-10 分鐘）
- 倉庫名稱或 URL 不正確
- 沒有 `index.html` 文件

**解決方案**:
1. 檢查倉庫是否是公開的
2. 檢查 GitHub Pages 設置是否已啟用
3. 等待幾分鐘後重新試
4. 清除瀏覽器快取（Ctrl+Shift+Del）

### 問題 2: 圖片無法顯示

**可能原因**:
- 圖片文件名有誤
- 檔案名區分大小寫
- 圖片未上傳到 GitHub

**解決方案**:
1. 檢查 `index.html` 中圖片路徑
2. 確保所有圖片都在 `images` 文件夾中
3. 使用相對路徑: `images/filename.jpg`
4. 重新推送文件

### 問題 3: 樣式（CSS）未生效

**可能原因**:
- CSS 文件路徑不正確
- 未推送 CSS 文件
- 瀏覽器快取問題

**解決方案**:
1. 清除瀏覽器快取
2. 檢查 `style.css` 是否在根目錄
3. 在 `index.html` 中確認 CSS 連結: `<link rel="stylesheet" href="style.css">`

### 問題 4: JavaScript 不工作

**可能原因**:
- JavaScript 文件未上傳
- 文件路徑不正確
- 瀏覽器快取

**解決方案**:
1. 檢查 `script.js` 是否已上傳
2. 在 `index.html` 中確認腳本連結: `<script src="script.js"></script>`
3. 打開瀏覽器開發者工具 (F12) 查看錯誤信息

## 後續更新與維護

### 修改內容後更新網站

1. **編輯本地文件**
   - 修改 HTML、CSS 或 JavaScript

2. **提交更改**
   ```bash
   git add .
   git commit -m "Update: description of changes"
   git push
   ```

3. **檢查網站**
   - 等待 1-2 分鐘
   - 訪問網站驗證更改

### 常用 Git 命令

```bash
# 查看狀態
git status

# 查看提交歷史
git log

# 撤銷最後一次提交
git reset --soft HEAD~1

# 查看遠端倉庫信息
git remote -v

# 拉取最新代碼
git pull origin main

# 強制推送（謹慎使用）
git push -f origin main
```

## 自定義域名（可選）

### 連接自己的域名

1. 購買域名（GoDaddy、Namecheap 等）
2. 進入倉庫 Settings → Pages
3. 在 "Custom domain" 填入你的域名
4. 在域名提供商設置 DNS 記錄
5. 等待 DNS 生效（通常 24 小時）

## 安全建議

### GitHub Pages 的限制

- 免費公開部署
- 不支持伺服器端語言（PHP、Python 等）
- 單純靜態網站
- 無需支付費用

### 隱私設置

- 倉庫內容是公開的
- 不要在代碼中包含敏感信息
- 避免上傳個人隱私照片

## 額外資源

### 官方文檔
- GitHub Pages 文檔: https://docs.github.com/en/pages
- Git 教程: https://git-scm.com/book/en/v2

### 在線工具
- Git 可視化工具: GitKraken, Sourcetree
- 代碼編輯器: VS Code, Sublime Text, Atom

### 推薦做法
- 定期提交代碼
- 使用有意義的提交信息
- 保持代碼整潔有序
- 備份本地文件

## 快速檢查清單

部署前確認以下項目已完成：

- [ ] GitHub 帳號已建立
- [ ] 倉庫已建立
- [ ] 所有文件準備好（HTML、CSS、JS）
- [ ] 所有圖片已放入 images 文件夾
- [ ] Git 已初始化
- [ ] 文件已提交到本地倉庫
- [ ] 已推送到 GitHub
- [ ] 網站可正常訪問
- [ ] 圖片顯示正常
- [ ] 樣式和功能正常

## 支援與幫助

如有問題：
1. 查看 GitHub Pages 官方文檔
2. 搜尋 Stack Overflow 相關問題
3. 查看瀏覽器開發者工具的錯誤信息
4. 聯絡課程助教或老師

---

**提示**: 網站 URL 會作為期末專案提交表單的一部分，請確保網站正常運作。

最後更新: 2026年6月20日
