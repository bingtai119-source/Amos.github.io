# Images 文件夾說明

此文件夾存放網站所需的所有圖片。請將以下圖片放入此文件夾：

## 必需的圖片文件

### 1. **profile.jpg** (推薦尺寸: 350x350px)
- 用途: 首頁個人照片
- 位置: Hero Section 右側
- 格式: JPG 或 PNG
- 說明: 應該是個人正面照片，最好穿著得體

### 2. **about.jpg** (推薦尺寸: 600x400px)
- 用途: 關於我頁面的照片
- 位置: About Section 左側
- 格式: JPG 或 PNG
- 說明: 可以是工作照、生活照或相關主題照片

### 3. **project1.jpg** (推薦尺寸: 400x250px)
- 用途: 第一個專案圖片 (網頁開發作品)
- 位置: Projects Section 卡片
- 格式: JPG 或 PNG
- 說明: 展示你的網頁開發項目的截圖或樣機

### 4. **project2.jpg** (推薦尺寸: 400x250px)
- 用途: 第二個專案圖片 (資料庫管理系統)
- 位置: Projects Section 卡片
- 格式: JPG 或 PNG
- 說明: 展示資料庫系統的介面截圖

### 5. **project3.jpg** (推薦尺寸: 400x250px)
- 用途: 第三個專案圖片 (課程結業作品)
- 位置: Projects Section 卡片
- 格式: JPG 或 PNG
- 說明: 展示完整應用程式的截圖

### 6. **activity1.jpg** (推薦尺寸: 300x250px 或更大)
- 用途: 參與活動照片 1
- 位置: Activity Photos Section
- 格式: JPG 或 PNG
- 說明: 校園活動、社團活動或課外活動照片

### 7. **activity2.jpg** (推薦尺寸: 300x250px 或更大)
- 用途: 參與活動照片 2
- 位置: Activity Photos Section
- 格式: JPG 或 PNG

### 8. **activity3.jpg** (推薦尺寸: 300x250px 或更大)
- 用途: 參與活動照片 3
- 位置: Activity Photos Section
- 格式: JPG 或 PNG

### 9. **activity4.jpg** (推薦尺寸: 300x250px 或更大)
- 用途: 參與活動照片 4
- 位置: Activity Photos Section
- 格式: JPG 或 PNG

## 圖片格式建議

### 支持的格式
- ✅ JPG (JPEG) - 最常用，文件較小
- ✅ PNG - 支持透明背景
- ✅ WebP - 現代格式，但需要確保兼容性
- ✅ GIF - 支持動畫

### 不支持的格式
- ❌ BMP
- ❌ TIFF
- ❌ SVG (可以使用，但需要特殊處理)

## 圖片優化建議

1. **解析度**: 建議 72-150 DPI 網頁解析度
2. **文件大小**: 
   - 個人照片: < 200KB
   - 項目圖片: < 150KB
   - 活動照片: < 150KB
3. **壓縮工具**: TinyPNG、ImageOptim、FileOptimizer
4. **格式選擇**:
   - 照片類: JPG (高壓縮率)
   - 圖表/設計: PNG (清晰度高)

## 快速設置指南

### 方式 1: 使用佔位符圖片
如果你還沒有準備好圖片，可以使用免費的佔位符服務：

```html
<!-- 例如：使用 Placeholder.com -->
<img src="https://via.placeholder.com/350" alt="個人照片">

<!-- 或使用 Lorem Picsum -->
<img src="https://picsum.photos/350/350?random=1" alt="個人照片">
```

但最終提交時必須使用真實圖片。

### 方式 2: 使用本地圖片
1. 準備好所有圖片文件
2. 將圖片放入 `images` 文件夾
3. 確保檔案名稱與 HTML 中引用的名稱完全相同（區分大小寫）
4. 檢查網站是否正常顯示

### 方式 3: 使用線上連結
可以暫時使用線上圖片連結（例如個人的 Google Drive 或雲服務），但建議最終部署時使用本地圖片。

## 圖片相關的 HTML 引用

當前 `index.html` 中的圖片引用：

```html
<!-- 個人照片 -->
<img src="images/profile.jpg" alt="個人照片" class="img-fluid rounded-circle hero-image">

<!-- 關於我照片 -->
<img src="images/about.jpg" alt="關於我" class="img-fluid rounded">

<!-- 專案圖片 -->
<img src="images/project1.jpg" class="card-img-top" alt="網頁開發作品">
<img src="images/project2.jpg" class="card-img-top" alt="資料庫管理系統">
<img src="images/project3.jpg" class="card-img-top" alt="課程作品">

<!-- 活動照片 -->
<img src="images/activity1.jpg" alt="活動1" class="img-fluid rounded activity-img">
<img src="images/activity2.jpg" alt="活動2" class="img-fluid rounded activity-img">
<img src="images/activity3.jpg" alt="活動3" class="img-fluid rounded activity-img">
<img src="images/activity4.jpg" alt="活動4" class="img-fluid rounded activity-img">
```

## 免費圖片資源推薦

### 免費圖庫網站
- Unsplash: https://unsplash.com/
- Pexels: https://www.pexels.com/
- Pixabay: https://pixabay.com/
- Freepik: https://www.freepik.com/
- Flaticon: https://www.flaticon.com/ (圖標)

### 佔位符服務
- Placeholder.com: https://placeholder.com/
- Lorem Picsum: https://picsum.photos/
- Placekitten: http://placekitten.com/

## 故障排除

### 問題: 圖片無法載入
**解決方案**:
1. 檢查檔案名稱是否正確（區分大小寫）
2. 確認圖片在 `images` 文件夾中
3. 檢查 HTML 中的路徑是否正確: `images/filename.jpg`
4. 清除瀏覽器快取並重新載入

### 問題: 圖片顯示但看起來很模糊
**解決方案**:
1. 使用更高解析度的圖片
2. 確保圖片寬度至少為 CSS 指定寬度的 2 倍
3. 使用 `srcset` 實現高 DPI 支持

### 問題: 圖片加載速度慢
**解決方案**:
1. 壓縮圖片文件
2. 使用現代格式（WebP）
3. 考慮使用懶加載

## 注意事項

⚠️ **重要**: 
- 所有圖片都需要在最終提交前準備好
- 確保圖片著作權無爭議（自己的照片或有授權的圖片）
- 個人照片應該是專業和清晰的
- 避免使用低品質或模糊的圖片

✅ **建議**:
- 準備至少 9 張圖片（1 個人照片 + 1 關於照片 + 3 項目圖片 + 4 活動照片）
- 保持圖片風格一致（色調、濾鏡等）
- 使用圖片編輯工具（Photoshop、GIMP、Canva）進行簡單編輯

---

最後更新: 2026年6月20日
