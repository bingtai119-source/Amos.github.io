# 快速入門指南

## 專案概覽

這是一個完整的個人網站模板，已為你準備好所有必要的代碼。只需按照以下步驟進行自定義和部署即可！

## 5 分鐘快速開始

### 1️⃣ 自定義個人信息 (5 分鐘)

編輯 `index.html` 文件，查找並替換以下內容：

```html
<!-- 第1步: 更改學號 -->
舊: <a class="navbar-brand fw-bold" href="#home">110001</a>
新: <a class="navbar-brand fw-bold" href="#home">YOUR_STUDENT_ID</a>

<!-- 第2步: 更改首頁文字 -->
舊: <h1 class="display-4 fw-bold mb-4">歡迎來到我的個人網站</h1>
新: <h1 class="display-4 fw-bold mb-4">歡迎來到YOUR_NAME的個人網站</h1>

<!-- 第3步: 更新自我介紹 -->
舊: <p class="lead mb-4">資管系學生｜網頁開發｜數據分析</p>
新: <p class="lead mb-4">YOUR_MAJOR學生｜YOUR_SKILL1｜YOUR_SKILL2</p>

<!-- 第4步: 更新基本信息 -->
舊: <strong>姓名：</strong>學生110001
新: <strong>姓名：</strong>YOUR_NAME

舊: <strong>學校：</strong>聯合大學
新: <strong>學校：</strong>YOUR_SCHOOL

舊: <strong>專業：</strong>資訊管理系
新: <strong>專業：</strong>YOUR_MAJOR
```

### 2️⃣ 添加你的照片 (3 分鐘)

1. 將你的照片放入 `images` 文件夾
2. 確保檔案名稱如下：
   - `profile.jpg` - 個人照片
   - `about.jpg` - 關於我照片
   - `project1.jpg`, `project2.jpg`, `project3.jpg` - 項目圖片
   - `activity1.jpg`, `activity2.jpg`, `activity3.jpg`, `activity4.jpg` - 活動照片

3. 如果檔案名稱不同，編輯 HTML 中對應的圖片路徑

### 3️⃣ 測試網站 (2 分鐘)

1. 打開 `index.html` 文件
   - 右鍵點擊檔案 → "使用默認程式打開" 
   - 或拖放到瀏覽器視窗

2. 檢查：
   - ✅ 網頁是否正常顯示
   - ✅ 導航連結是否工作
   - ✅ 圖片是否顯示
   - ✅ 響應式設計（改變窗口大小測試）

## 完整自定義清單

### 基本信息
- [ ] 學號
- [ ] 姓名
- [ ] 學校名稱
- [ ] 系所名稱
- [ ] 興趣愛好
- [ ] 聯絡郵箱

### 教育背景
- [ ] 大學名稱
- [ ] 入學年份和預計畢業年份
- [ ] 主修課程列表
- [ ] 學位信息

### 經驗與技能
- [ ] 實習或工作經驗
- [ ] 志願服務經驗
- [ ] 技能列表和評級
- [ ] 軟體和工具

### 專案作品
- [ ] 項目1標題和說明
- [ ] 項目2標題和說明
- [ ] 項目3標題和說明
- [ ] 技術標籤
- [ ] 項目連結或 GitHub URL

### 文章和獲獎
- [ ] 文章標題和發表日期
- [ ] 文章說明
- [ ] 獲獎項目
- [ ] 學術成就
- [ ] 競賽成績

### 聯絡方式
- [ ] 電子郵件地址
- [ ] Facebook 連結
- [ ] GitHub 連結
- [ ] LinkedIn 連結

## 文件編輯指南

### 編輯 HTML (index.html)

使用文字編輯器打開 `index.html`：
- Windows: 記事本、VS Code、Sublime Text
- Mac: TextEdit、VS Code

**編輯提示**:
```html
<!-- 查找這些部分並修改文字 -->
<h1>標題</h1>        <!-- 大標題 -->
<h2>副標題</h2>      <!-- 副標題 -->
<p>文字內容</p>      <!-- 段落文字 -->
<strong>重點</strong>  <!-- 粗體 -->
```

### 編輯 CSS (style.css)

如果想改變顏色、字體或其他樣式：

```css
/* 改變主色調（藍色改為紅色） */
.btn-primary {
    background-color: #FF6B6B;  /* 改為紅色 */
    border-color: #FF6B6B;
}

/* 改變導航欄背景 */
.navbar {
    background-color: #333;  /* 改為你喜歡的顏色 */
}

/* 改變標題顏色 */
h1, h2, h3 {
    color: #333;  /* 改為你的顏色 */
}
```

常用顏色代碼：
- 藍色: `#007bff`
- 紅色: `#FF6B6B`
- 綠色: `#4CAF50`
- 黃色: `#FFC107`
- 紫色: `#9C27B0`
- 灰色: `#808080`

## 常見編輯位置

### 位置 1: 首頁標題（第 68 行左右）
```html
<h1 class="display-4 fw-bold mb-4">歡迎來到我的個人網站</h1>
```

### 位置 2: 自我介紹（第 69 行左右）
```html
<p class="lead mb-4">資管系學生｜網頁開發｜數據分析</p>
```

### 位置 3: 基本資訊（第 146 行左右）
```html
<p><strong>姓名：</strong>學生110001</p>
```

### 位置 4: 實習經驗（第 204 行左右）
```html
<h6 class="mb-2">實習生 - ABC科技公司</h6>
```

### 位置 5: 技能評級（第 224 行左右）
```html
<div class="progress-bar" style="width: 90%"></div>
```

### 位置 6: 文章標題（第 367 行左右）
```html
<h6>現代網頁開發的最佳實踐</h6>
```

### 位置 7: 獲獎項目（第 400 行左右）
```html
<strong>校內程式設計競賽 優選</strong>
```

## 部署步驟

### 第 1 步: 準備所有文件
```
110001/
├── index.html ✅ 已準備
├── style.css ✅ 已準備
├── script.js ✅ 已準備
└── images/ ✅ 已建立
```

### 第 2 步: 添加圖片
1. 將 9 張圖片放入 `images` 文件夾
2. 確認檔案名稱正確

### 第 3 步: 推送到 GitHub
參照 `GITHUB_PAGES_GUIDE.md` 中的步驟

### 第 4 步: 錄製說明影片
參照 `VIDEO_GUIDE.md` 中的步驟

### 第 5 步: 提交表單
填寫: https://forms.gle/UsUwQyUkDcd2j5f37

## 快速參考

### 導航連結
```html
<!-- 添加新導航項目 -->
<li class="nav-item"><a class="nav-link" href="#section-id">Section Name</a></li>
```

### 添加新卡片
```html
<div class="card card-custom">
    <div class="card-body">
        <h5 class="card-title">標題</h5>
        <p>內容</p>
    </div>
</div>
```

### 添加進度條
```html
<div class="skill-item">
    <div class="d-flex justify-content-between">
        <span>技能名稱</span>
        <span>85%</span>
    </div>
    <div class="progress">
        <div class="progress-bar" style="width: 85%"></div>
    </div>
</div>
```

### 添加圖片
```html
<img src="images/filename.jpg" alt="描述" class="img-fluid rounded">
```

## 故障排除

### 問題: HTML 編輯後沒有變化
**解決方案**:
1. 保存文件 (Ctrl+S)
2. 重新加載瀏覽器 (Ctrl+F5 或 Cmd+Shift+R)
3. 清除瀏覽器快取

### 問題: 圖片顯示為問號
**解決方案**:
1. 檢查圖片是否在 `images` 文件夾中
2. 確認檔案名稱完全相同（區分大小寫）
3. 確認路徑為 `images/filename.jpg`

### 問題: 樣式看起來不對
**解決方案**:
1. 檢查 CSS 文件是否已加載
2. 檢查是否有 CSS 衝突
3. 使用瀏覽器開發者工具（F12）檢查

### 問題: 提交時報錯
**解決方案**:
1. 確認所有必填欄位已填寫
2. 檢查 URL 是否可訪問
3. 確認影片連結有效

## 進階定制

### 修改字體
```css
body {
    font-family: 'Noto Sans Traditional Chinese', sans-serif;
    /* 改為你喜歡的字體 */
}
```

### 添加額外部分
1. 複製現有卡片代碼
2. 修改標題和內容
3. 保持 CSS 類名相同以保持樣式

### 修改響應式斷點
在 `style.css` 中找到 `@media` 查詢並修改數值

## 時間管理建議

| 任務 | 時間 |
|------|------|
| 自定義個人信息 | 30 分鐘 |
| 準備和優化圖片 | 1 小時 |
| 測試網站功能 | 15 分鐘 |
| 推送到 GitHub | 30 分鐘 |
| 錄製說明影片 | 1-2 小時 |
| 編輯影片 | 30 分鐘 |
| 提交表單 | 5 分鐘 |
| **總計** | **4-5 小時** |

## 最終檢查清單

在提交前確認以下項目：

### 網站內容
- [ ] 所有個人信息已更新
- [ ] 所有照片已添加
- [ ] 所有技能已列出
- [ ] 所有專案已說明
- [ ] 所有文章和獲獎已填寫

### 網站功能
- [ ] 所有連結都可點擊
- [ ] 導航正常工作
- [ ] 表單可以提交
- [ ] 沒有 JavaScript 錯誤

### 響應式設計
- [ ] 桌面版本正確顯示
- [ ] 平板版本正確顯示
- [ ] 手機版本正確顯示

### 部署
- [ ] 網站已推送到 GitHub
- [ ] 網址可以正常訪問
- [ ] 所有文件都已上傳

### 說明影片
- [ ] 影片已錄製
- [ ] 影片長度 < 3 分鐘
- [ ] 音質清晰
- [ ] 影片已上傳到線上平台

### 提交表單
- [ ] 學號已填寫
- [ ] 姓名已填寫
- [ ] 網站 URL 已填寫
- [ ] 影片 URL 已填寫
- [ ] 表單已提交

## 聯繫與支持

如有問題：
1. 查看相關指南文檔
2. 查看瀏覽器開發者工具錯誤信息
3. 搜尋相關技術文檔
4. 聯絡課程助教或老師

## 下一步

1. 開始編輯 `index.html` 文件
2. 準備你的照片
3. 按照 `GITHUB_PAGES_GUIDE.md` 推送代碼
4. 按照 `VIDEO_GUIDE.md` 錄製影片
5. 填寫提交表單

---

**記住**: 截止日期是 2026 年 6 月 25 日，不要遲交！

最後更新: 2026年6月20日
