function ready(callback) {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', callback);
    } else {
        callback();
    }
}

ready(function () {
    setupSmoothScroll();
    setupMessageForm();
    loadMessageBoard();
    setupProjectImageModal();
});

function setupProjectImageModal() {
    const links = document.querySelectorAll('.project-image-link');
    const modalImage = document.getElementById('projectModalImage');
    const modalTitle = document.getElementById('projectImageModalLabel');

    links.forEach(link => {
        link.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();

            const imageSrc = this.getAttribute('data-image-src');
            const imageTitle = this.getAttribute('data-image-title');
            if (modalImage) {
                modalImage.src = imageSrc;
                modalImage.alt = imageTitle || '專案圖片';
            }
            if (modalTitle) {
                modalTitle.textContent = imageTitle || '';
            }
        });
    });
}

function setupSmoothScroll() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    navLinks.forEach(link => {
        const targetId = link.getAttribute('href');
        if (!targetId || targetId === '#') {
            return;
        }

        link.addEventListener('click', function (event) {
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                event.preventDefault();
                event.stopPropagation();

                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
                window.scrollTo({ top: targetPosition, behavior: 'smooth' });
                window.history.replaceState(null, '', targetId);

                const navbarCollapse = document.querySelector('.navbar-collapse.show');
                if (navbarCollapse && window.bootstrap) {
                    const bsCollapse = window.bootstrap.Collapse.getInstance(navbarCollapse);
                    if (bsCollapse) {
                        bsCollapse.hide();
                    }
                }
            }
        });
    });
}

function setupMessageForm() {
    const siteMessageForm = document.getElementById('siteMessageForm');
    if (!siteMessageForm) {
        return;
    }

    siteMessageForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const visitorName = document.getElementById('visitorName').value.trim();
        const visitorMessage = document.getElementById('visitorMessage').value.trim();
        if (!visitorName || !visitorMessage) {
            alert('請填寫姓名與留言內容。');
            return;
        }

        const message = {
            name: visitorName,
            content: visitorMessage,
            timestamp: new Date().toISOString()
        };

        saveMessage(message);
        appendMessageToBoard(message);
        siteMessageForm.reset();

        const feedback = document.getElementById('messageFeedback');
        if (feedback) {
            feedback.classList.remove('d-none');
            setTimeout(() => feedback.classList.add('d-none'), 3000);
        }
    });
}

function getSavedMessages() {
    const stored = localStorage.getItem('siteMessages');
    return stored ? JSON.parse(stored) : [];
}

function saveMessage(message) {
    const messages = getSavedMessages();
    messages.unshift(message);
    localStorage.setItem('siteMessages', JSON.stringify(messages.slice(0, 20)));
}

function loadMessageBoard() {
    const messages = getSavedMessages();
    messages.forEach(appendMessageToBoard);
}

function appendMessageToBoard(message) {
    const messageList = document.getElementById('messageList');
    if (!messageList) {
        return;
    }

    const item = document.createElement('div');
    item.className = 'list-group-item list-group-item-action mb-2';
    item.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-2">
            <strong>${escapeHtml(message.name)}</strong>
            <small class="text-muted">${formatMessageTime(message.timestamp)}</small>
        </div>
        <p class="mb-0">${escapeHtml(message.content)}</p>
    `;

    messageList.prepend(item);
}

function formatMessageTime(isoString) {
    const date = new Date(isoString);
    return date.toLocaleString('zh-TW', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function escapeHtml(text) {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// 控制台歡迎訊息
console.log('%c歡迎來到我的個人網站！', 'color: #007bff; font-size: 20px; font-weight: bold;');
console.log('%c感謝您的訪問！如有任何建議，歡迎聯絡我。', 'color: #666; font-size: 14px;');

// 頁面可見性 API（可選）
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        console.log('頁面已隱藏');
    } else {
        console.log('歡迎回來！');
    }
});
